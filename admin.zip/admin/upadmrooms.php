<?php
include '../config.php';

$id_kamar = $_POST['id_kamar'];
$tipe_kamar = $_POST['tipe_kamar'];
$jml_kamar = $_POST['jml_kamar'];
$harga_kamar = $_POST['harga_kamar'];
$Fasilitas = $_POST['Fasilitas'];

mysqli_query($koneksi, "UPDATE tb_tipekamar SET id_kamar='$id_kamar', tipe_kamar ='$tipe_kamar', 
jml_kamar='$jml_kamar', harga_kamar='$harga_kamar', Fasilitas='$Fasilitas' WHERE id_kamar='$id_kamar'");

header("location: admrooms.php");
?>