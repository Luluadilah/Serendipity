<?php
include '../config.php';
$id_fasilitas = $_POST['id_fasilitas'];
$nama_fasilitas = $_POST['nama_fasilitas'];
$ket = $_POST['ket'];

mysqli_query($koneksi, "INSERT INTO tb_fasilitas VALUES('','$nama_fasilitas','$ket')");

header("location: admfacilities.php");
?>