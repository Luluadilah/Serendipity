<?php
include '../config.php';
$id_kamar = $_POST['id_kamar'];
$tipe_kamar = $_POST['tipe_kamar'];
$jml_kamar = $_POST['jml_kamar'];
$harga_kamar = $_POST['harga_kamar'];
$Fasilitas = $_POST['Fasilitas'];

mysqli_query($koneksi, "INSERT into tb_tipekamar values('','$tipe_kamar','$jml_kamar','$harga_kamar','$Fasilitas')");

header("location: admrooms.php");
?>