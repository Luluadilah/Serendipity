<?php
include '../config.php';

$id_fasilitas = $_POST['id_fasilitas'];
$nama_fasilitas = $_POST['nama_fasilitas'];
$ket = $_POST['ket'];

mysqli_query($koneksi, "UPDATE tb_fasilitas SET id_fasilitas='$id_fasilitas', nama_fasilitas ='$nama_fasilitas', 
ket='$ket' WHERE id_fasilitas='$id_fasilitas'");

header("location: admfacilities.php");
?>